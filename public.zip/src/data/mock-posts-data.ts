export const skills = [
  { name: "Next.js", icon: "nextjs" },
  { name: "Laravel", icon: "laravel" },
  { name: "Tailwind CSS", icon: "tailwind" },
  { name: "TypeScript", icon: "ts" },
  { name: "Framer Motion", icon: "framer" },
];
export const projects = [
  {
    id: "1",
    title: "Sistem POS UMKM",
    description:
      "Aplikasi kasir & pembukuan berbasis web dengan Laravel + React.",
    image: "/images/project1.jpg",
    link: "#",
  },
  {
    id: "2",
    title: "Portfolio Modern",
    description: "Website portfolio dengan Next.js, Tailwind, shadcn/ui.",
    image: "/images/project2.jpg",
    link: "#",
  },
];
export const experience = [
  {
    year: "2023 - Sekarang",
    role: "Fullstack Developer",
    company: "Freelance",
    description:
      "Mengembangkan aplikasi web untuk klien lokal & internasional.",
  },
  {
    year: "2022",
    role: "Intern Web Developer",
    company: "Startup X",
    description: "Mengerjakan modul frontend & backend kecil-kecilan.",
  },
];
export const testimonials = [
  { name: "Andi", text: "Profesional & cepat tanggap. Hasil memuaskan!" },
  { name: "Budi", text: "Koding rapi, mudah dikembangkan lagi." },
];

export type Post = {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  tags: string[];
  publishedAt: string;
};
export const posts: Post[] = [
  {
    id: "1",
    title: "Membangun Portfolio Modern dengan Next.js",
    slug: "portfolio-modern-nextjs",
    excerpt:
      "Langkah-langkah praktis membangun portfolio yang cepat danelegan.",
    content: `# Judul H1\n\nIni contoh konten **Markdown style**. Gunakan
Tailwind typography untuk tampilan rapi.`,
    tags: ["nextjs", "frontend"],
    publishedAt: "2025-08-01",
  },
  {
    id: "2",
    title: "Workflow Dev → Staging → Prod di Vercel",
    slug: "workflow-vercel-3-stage",
    excerpt: "Strategi branch & environment untuk rilis mulus.",
    content: `## Section\n\nPreview deployments memudahkan QA sebelum ke
production.`,
    tags: ["vercel", "devops"],
    publishedAt: "2025-08-10",
  },
  // Tambah lagi sesuai kebutuhan
];
