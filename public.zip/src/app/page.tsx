"use client"
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

import { projects, experience, testimonials, posts } from '@/data/mock-posts-data'
import PageTransition from '@/components/site/page-transition'
import HeroSection from '@/components/organism/HeroSectionV1'
import AboutSection from '@/components/organism/AboutSectionV2'
import TechStackSection from '@/components/organism/TechStackSectionV2'
import LatestProject from '@/components/organism/LatestProjectSectionV1'
import Particles from '@/components/organism/Particles'
export default function HomePage() {
  function toggleTheme() {
    document.documentElement.classList.toggle("dark")
  }
  return (
    // <PageTransition className='bg-gradient-to-tl from-black via-zinc-600/20 to-black'>
    <PageTransition >
      {/* Hero Section */}
      <HeroSection />

      {/* About Section */}
      <AboutSection />

      {/* Skills Section */}
      <TechStackSection />

      {/* Projects Section */}
      <LatestProject />

      {/* <Particles
        className="absolute inset-0 -z-10 animate-fade-in"
        quantity={100}
      /> */}
      {/*  */}
      {/* Experience Section */}
      <section className="container py-20 max-w-3xl">
        <h2 className="text-2xl font-bold text-center">Pengalaman</h2>
        <div className="mt-8 space-y-6">
          {experience.map((exp, i) => (
            <div key={i} className="border-l-2 pl-4">
              <p className="text-sm text-muted-foreground">{exp.year}</p>
              <h3 className="font-semibold">{exp.role} — {exp.company}</h3>
              <p className="text-muted-foreground">{exp.description}</p>
            </div>
          ))}
        </div>
      </section>
      {/* Testimonials Section */}
      <section className="container py-20">
        <h2 className="text-2xl font-bold text-center">Testimoni</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {testimonials.map((t, i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <p className="italic">“{t.text}”</p>
                <p className="mt-2 font-semibold">— {t.name}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
      {/* Blog Preview */}
      <section className="container py-20">
        <h2 className="text-2xl font-bold text-center">Tulisan Terbaru</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.slice(0, 3).map((p) => (

            < Card key={p.id} >
              <CardHeader>
                <CardTitle><Link href={`/blog/${p.slug}`}
                  className="hover:underline">{p.title}</Link></CardTitle>
              </CardHeader>
              <CardContent>
                <p className="line-clamp-3 text-muted-foreground">{p.excerpt}</
                p>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Button asChild variant="outline"><Link href="/blog">Lihat Semua</
          Link></Button>
        </div>
      </section>
      {/* Contact CTA */}
      <section className="container py-20 text-center">
        <h2 className="text-2xl font-bold">Mari Bekerja Sama</h2>
        <p className="mt-4 text-muted-foreground">Tertarik berkolaborasi atau
          butuh bantuan proyek? Silakan hubungi saya.</p>
        <div className="mt-6">
          <Button asChild size="lg"><Link href="/contact">Hubungi Saya</Link></
          Button>
        </div>
      </section>
      <button
        onClick={toggleTheme}
        className="px-4 py-2 rounded bg-primary text-primary-foreground"
      >
        Toggle Dark Mode
      </button>
    </PageTransition >
  )
}