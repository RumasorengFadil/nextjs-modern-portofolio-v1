import Image from "next/image";

export default function AboutSection() {
    return (
        <section className="container flex flex-col mx-auto py-20 w-max">
            <h2 className="text-4xl font-bold ">About Me</h2>

            <div className="flex items-center gap-10 flex-col sm:flex-row">
                <p className="mt-4 text-muted-foreground max-w-96">Saya memiliki pengalaman
                    dalam membangun aplikasi berbasis web dari frontend hingga backend. Fokus saya
                    pada clean code, UX yang baik, dan solusi yang efisien.</p>
                <div className="flex-1">
                <Image src="/images/app/hero-photo.png" width={200} height={200} alt="about-photo" />

                </div>
            </div>
        </section>
    )
}
